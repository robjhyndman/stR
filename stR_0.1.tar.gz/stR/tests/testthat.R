library(testthat)
library(stR)

test_check("stR")
