#' @title Estimates model parameters and decomposes data.
#' @description Estimates model parameters and decomposes input (time series of class \code{ts}) using the estimated model.
#'
#' @seealso \code{\link{AutoSTR}}, \code{\link{AutoSTR.msts}}
#' @param data A time series of class \code{ts}.
#' @inheritParams gapCV
#' @inheritParams lambdas
#' @inheritParams reltol
#' @inheritParams confidence
#' @param nsKnots An optional vector parameter. It defines number of seasonal knots (per period) for each sesonal component.
#' @templateVar class STR
#' @templateVar topLevel1 \item \strong{cvMSE} -- optional cross validated (leave one out) Mean Squared Error.
#' @templateVar topLevel2 \item \strong{optim.CV.MSE} -- best cross validated Mean Squared Error (n-fold) achieved during minimisation procedure.
#' @templateVar topLevel3 \item \strong{nFold} -- the input \code{nFold} parameter.
#' @templateVar topLevel4 \item \strong{gapCV} -- the input \code{gapCV} parameter.
#' @templateVar topLevel5 \item \strong{method} -- always contains string \code{"AutoSTR"} for this function.
#' @template returnValue
#' @author Alexander Dokumentov
#' @export

AutoSTR.ts = function(data, gapCV = NULL, lambdas = NULL, reltol = 0.001, confidence = NULL, nsKnots = NULL)
{
  if(!("ts" %in% class(data))) stop('Parameter "data" must be of class "ts".')
  # AutoSTR.msts also works with ts class
  str = AutoSTR.msts(data = data,
                     gapCV = gapCV,
                     lambdas = lambdas,
                     reltol = reltol,
                     confidence = confidence,
                     nsKnots = nsKnots)
  return(str)
}
