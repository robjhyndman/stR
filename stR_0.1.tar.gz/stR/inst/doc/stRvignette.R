## ---- fig.show='hold', fig.width = 7, fig.height = 4.5-------------------
plot(stl(log(co2), s.window = "per", t.window = 30))

